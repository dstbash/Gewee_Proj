#ifndef __APPLY_H
#define __APPLY_H

#include "led.h"
#include "24cxx.h"
#include "TM1640.h"
#include "adc.h"
#include "iwdg.h"
#include "scheduler.h"
#include "sys_set.h"

void Init_APPLY(void);

#endif


/******************** (C)COPYRIGHT(2018) YaoCheng END OF FILE **********************/
