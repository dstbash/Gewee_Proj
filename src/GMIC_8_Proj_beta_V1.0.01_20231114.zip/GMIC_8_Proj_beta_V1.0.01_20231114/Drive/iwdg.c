/**
  ******************************************************************************
  * @file    iwdg.c
  * @author  �׳ɵ��ӿƼ�
  * @version V1.0
  * @date    2018-7-23
  * @brief   ��
  ******************************************************************************
  * @attention
  *
  * ��
  *
  ******************************************************************************
  */ 
	
	
#include "iwdg.h"


/** 
  * @name   Check_Watchdog_Reset
  
  * @brief  ��鿴�Ź���λ
  
  * @param  ��
  
  * @retval 0�����ǿ��Ź���λ��1���ǿ��Ź���λ��
  */
char Check_Watchdog_Reset(void)
{
	/* Check if the system has resumed from IWDG reset */
  if (RCC_GetFlagStatus(RCC_FLAG_IWDGRST) != RESET)
  {
		RCC_ClearFlag();/* Clear reset flags */
    return 1;
  }
  return 0;
}

/** 
  * @name   Init_Watchdog
  
  * @brief  ��ʼ�����Ź�
  
  * @param  time������
  
  * @retval ��
  */
void Init_Watchdog(unsigned int time)
{
  IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);			/* Enable write access to IWDG_PR and IWDG_RLR registers */
  IWDG_SetPrescaler(IWDG_Prescaler_256);						/* IWDG counter clock: LSI/256 Ԥ��Ƶ */

  /* Set counter reload value to obtain 250ms IWDG TimeOut.
     Counter Reload Value = 250ms/IWDG counter clock period
                          = 250ms / (LSI/256)
                          = 0.25s / (lsi_freq/256)
                          = lsi_freq/(256 * 4)
                          = lsi_freq/1024
   */
  IWDG_SetReload(time);
  IWDG_ReloadCounter();															/* Reload IWDG counter */
  IWDG_Enable();																		/* Enable IWDG (the LSI oscillator will be enabled by hardware) */
}

/** 
  * @name   Feed_Watchdog
  
  * @brief  ι��
  
  * @param  ��
  
  * @retval ��
  */
void Feed_Watchdog(void)
{
  IWDG_ReloadCounter();  /* Reload IWDG counter */
}


/******************** (C)COPYRIGHT(2018) YaoCheng END OF FILE **********************/
