/**
  ******************************************************************************
  * @file    iwdg.h
  * @author  �׳ɵ��ӿƼ�
  * @version V1.0
  * @date    2023-6-7
  * @brief   ��
  ******************************************************************************
  * @attention
  ******************************************************************************
  */
#ifndef __IWDG_H
#define __IWDG_H


#include "stm32f0xx_iwdg.h"


char Check_Watchdog_Reset(void);
void Init_Watchdog(unsigned int time);
void Feed_Watchdog(void);


#endif


/******************** (C)COPYRIGHT(2018) YaoCheng END OF FILE **********************/
