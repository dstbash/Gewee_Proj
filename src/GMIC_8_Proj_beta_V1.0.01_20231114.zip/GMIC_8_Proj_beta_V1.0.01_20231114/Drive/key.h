/**
  ******************************************************************************
  * @file    adc.h
  * @author  �׳ɵ��ӿƼ�
  * @version V1.0
  * @date    2023-6-7
  * @brief   ��
  ******************************************************************************
  * @attention
  ******************************************************************************
  */
#ifndef __KEY_H
#define __KEY_H

#include "stm32f0xx.h"
#include "time3.h"
#include "adc.h"
#include "save_data.h"
#include "led.h"

extern unsigned char AddrNum;
void Key_Config(void);
unsigned char Get_addr(void);
void key_detect(void);
#endif
/******************** (H)COPYRIGHT(2023) YaoCheng END OF FILE **********************/
