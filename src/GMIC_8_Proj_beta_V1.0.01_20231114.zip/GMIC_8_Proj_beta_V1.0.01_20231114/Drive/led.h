/**
  ******************************************************************************
  * @file    led.h
  * @author  �׳ɵ��ӿƼ�
  * @version V1.0
  * @date    2018-7-23
  * @brief   ��
  ******************************************************************************
  * @attention
  *
  * ��
  *
  ******************************************************************************
  */ 
	
#ifndef __LED_H
#define __LED_H

#include "stm32f0xx.h"

#define RUN_LED(x) x ? GPIO_ResetBits(GPIOB,GPIO_Pin_3) : GPIO_SetBits(GPIOB,GPIO_Pin_3);
#define RUN_LED_JUMP GPIO_WriteBit(GPIOB,GPIO_Pin_3,(BitAction)(1-GPIO_ReadOutputDataBit(GPIOB, GPIO_Pin_3)))		//����LED�˿ڣ���ƽ���з�ת

extern void Led_Init(void);
#endif

/******************** (H)COPYRIGHT(2018) YaoCheng END OF FILE **********************/
