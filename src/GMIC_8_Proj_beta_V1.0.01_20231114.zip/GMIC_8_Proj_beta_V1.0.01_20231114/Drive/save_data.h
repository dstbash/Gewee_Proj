#ifndef __SAVE_DATA_H
#define __SAVE_DATA_H

#include "stm32f0xx.h"

#include "24cxx.h"


char Read_Sensor_Zero_Data(unsigned short addr,float *Sensor_Zero);
char Write_Sensor_Zero_Data(unsigned short addr,float *correct_zero);

#endif

