/**
  ******************************************************************************
  * @file    sys_set.c
  * @author  �׳ɵ��ӿƼ�
  * @version V1.0
  * @date    2018-7-23
  * @brief   ��
  ******************************************************************************
  * @attention
  *
  * ��
  *
  ******************************************************************************
  */ 
	
	
#include "sys_set.h"
#include "stm32f0xx_misc.h"
#include "stm32f0xx_rcc.h"


/** 
  * @name   Config_SysTick
  
  * @brief  ����ϵͳ�δ�ʱ��
  
  * @param  ��
  
  * @retval ��
  */
void Config_SysTick(void)
{
	/* Setup SysTick Timer for 1 msec interrupts.
     ------------------------------------------
    1. The SysTick_Config() function is a CMSIS function which configure:
       - The SysTick Reload register with value passed as function parameter.
       - Configure the SysTick IRQ priority to the lowest value (0x0F).
       - Reset the SysTick Counter register.
       - Configure the SysTick Counter clock source to be Core Clock Source (HCLK).
       - Enable the SysTick Interrupt.
       - Start the SysTick Counter.
    
    2. You can change the SysTick Clock source to be HCLK_Div8 by calling the
       SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8) just after the
       SysTick_Config() function call. The SysTick_CLKSourceConfig() is defined
       inside the misc.c file.

    3. You can change the SysTick IRQ priority by calling the
       NVIC_SetPriority(SysTick_IRQn,...) just after the SysTick_Config() function 
       call. The NVIC_SetPriority() is defined inside the core_cm0.h file.

    4. To adjust the SysTick time base, use the following formula:
                            
         Reload Value = SysTick Counter Clock (Hz) x  Desired Time base (s)
    
       - Reload Value is the parameter to be passed for SysTick_Config() function
       - Reload Value should not exceed 0xFFFFFF
   */
  if (SysTick_Config(SystemCoreClock / 1000))
  { 
    /* Capture error */ 
    while (1);
  }
	
  /* Configure the SysTick handler priority */
  NVIC_SetPriority(SysTick_IRQn, 0x0);
}

/** 
  * @name   Get_SYSCLK_Mess
  
  * @brief  ��ȡϵͳʱ����Ϣ
  
  * @param  ��
  
  * @retval ��
  */
void Get_SYSCLK_Mess(void)
{
	__attribute__((unused)) unsigned char clock_source=0;
	RCC_ClocksTypeDef RCC_Clocks;
	clock_source=RCC_GetSYSCLKSource();			//��ȡϵͳʱ��Դ
	RCC_GetClocksFreq(&RCC_Clocks);					//��ȡϵͳʱ��Ƶ��
}

/** 
  * @name   Init_SysTick
  
  * @brief  ��ʼ���δ�ʱ����1ms��
  
  * @param  ��
  
  * @retval ��
  */
void Init_SysTick(void)
{
	if (SysTick_Config(SystemCoreClock / 1000))
  { 
    /* Capture error */ 
    while (1);
  }
}


/******************** (C)COPYRIGHT(2018) YaoCheng END OF FILE **********************/
