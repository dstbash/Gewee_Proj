#ifndef __SYS_SET_H
#define __SYS_SET_H


void Config_SysTick(void);
void Get_SYSCLK_Mess(void);
void Init_SysTick(void);


#endif


/******************** (C)COPYRIGHT(2018) YaoCheng END OF FILE **********************/
