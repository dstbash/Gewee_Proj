#ifndef __TIME3_H
#define __TIME3_H

#include "stm32f0xx.h"

extern unsigned int key_flag;

void Timer_Init(void);
void TIM_Agree_Parse_Init(uint32_t tim_period);
#endif
