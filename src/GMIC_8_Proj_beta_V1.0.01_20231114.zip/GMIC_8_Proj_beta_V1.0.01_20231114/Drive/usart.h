/**
  ******************************************************************************
  * @file    usart.h
  * @author  �׳ɵ��ӿƼ�
  * @version V1.0
  * @date    2023-6-7
  * @brief   ��
  ******************************************************************************
  * @attention
  ******************************************************************************
  */
#ifndef __USART_H
#define __USART_H

#include "stm32f0xx.h"
#include "stdlib.h"
#include "string.h"
#include "stdio.h"
#include "package.h"
#include "ringbuffer.h"

void Usart_Init(uint32_t BaudRate);
void USART1_SendBuf(uint8_t *pBuf, uint32_t u32Len);
uint8_t USART1_ReciverBuf(void);
int fputc(int ch, FILE *f);

#endif
/******************** (H)COPYRIGHT(2023) YaoCheng END OF FILE **********************/



