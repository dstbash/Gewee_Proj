var searchData=
[
  ['intrinsic_20functions_20for_20cpu_20instructions',['Intrinsic Functions for CPU Instructions',['../group__intrinsic___c_p_u__gr.html',1,'']]],
  ['intrinsic_20functions_20for_20simd_20instructions_20_5bonly_20cortex_2dm4_5d',['Intrinsic Functions for SIMD Instructions [only Cortex-M4]',['../group__intrinsic___s_i_m_d__gr.html',1,'']]],
  ['interrupts_20and_20exceptions_20_28nvic_29',['Interrupts and Exceptions (NVIC)',['../group___n_v_i_c__gr.html',1,'']]]
];
